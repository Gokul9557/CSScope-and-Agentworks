"""Callable tools used by AgentWorks."""

from __future__ import annotations

import ast
import operator
from pathlib import Path
from typing import Any, Callable

from csscope.parser import analyze_css

ToolFunction = Callable[..., dict[str, Any]]


def result_ok(data: Any) -> dict[str, Any]:
    return {"ok": True, "data": data, "error": None}


def result_error(message: str) -> dict[str, Any]:
    return {"ok": False, "data": None, "error": message}


def _evaluate(expression: str) -> float | int:
    if not expression.strip() or len(expression) > 200:
        raise ValueError("Enter an arithmetic expression of at most 200 characters.")
    try:
        tree = ast.parse(expression, mode="eval")
    except SyntaxError as exc:
        raise ValueError("That is not a valid arithmetic expression.") from exc

    binary_ops: dict[type[ast.operator], Callable[[Any, Any], Any]] = {
        ast.Add: operator.add,
        ast.Sub: operator.sub,
        ast.Mult: operator.mul,
        ast.Div: operator.truediv,
        ast.FloorDiv: operator.floordiv,
        ast.Mod: operator.mod,
        ast.Pow: operator.pow,
    }
    unary_ops: dict[type[ast.unaryop], Callable[[Any], Any]] = {
        ast.UAdd: operator.pos,
        ast.USub: operator.neg,
    }

    def visit(node: ast.AST) -> float | int:
        if isinstance(node, ast.Expression):
            return visit(node.body)
        if isinstance(node, ast.Constant) and type(node.value) in (int, float):
            if abs(node.value) > 10**100:
                raise ValueError("Number is too large.")
            return node.value
        if isinstance(node, ast.BinOp) and type(node.op) in binary_ops:
            left, right = visit(node.left), visit(node.right)
            if isinstance(node.op, ast.Pow) and abs(right) > 100:
                raise ValueError("Exponent magnitude must be 100 or less.")
            value = binary_ops[type(node.op)](left, right)
            if isinstance(value, (int, float)) and abs(value) > 10**100:
                raise ValueError("Result is too large.")
            return value
        if isinstance(node, ast.UnaryOp) and type(node.op) in unary_ops:
            return unary_ops[type(node.op)](visit(node.operand))
        raise ValueError("Only numeric literals and basic arithmetic operators are allowed.")

    value = visit(tree)
    if not isinstance(value, (int, float)):
        raise ValueError("Expression did not produce a number.")
    return value


def calculator(expression: str) -> dict[str, Any]:
    """Evaluate arithmetic using a restricted Python AST (never eval)."""
    if not isinstance(expression, str):
        return result_error("Expression must be text.")
    try:
        return result_ok({"expression": expression, "result": _evaluate(expression)})
    except (ValueError, ZeroDivisionError, OverflowError) as exc:
        return result_error(str(exc) or "Could not calculate that expression.")


def text_utility(text: str, operation: str = "summary") -> dict[str, Any]:
    if not isinstance(text, str):
        return result_error("Text must be a string.")
    if operation not in {"word_count", "character_count", "summary"}:
        return result_error("Choose word_count, character_count, or summary.")
    words = text.split()
    if operation == "word_count":
        data = {"word_count": len(words)}
    elif operation == "character_count":
        data = {"character_count": len(text)}
    else:
        snippet = " ".join(words)
        if len(snippet) > 180:
            snippet = snippet[:177].rstrip() + "..."
        data = {
            "word_count": len(words),
            "character_count": len(text),
            "summary": snippet or "(empty text)",
        }
    return result_ok(data)


def inspect_css_file(
    path: str,
    *,
    selected_file: bool = False,
    sample_dir: str | Path | None = None,
) -> dict[str, Any]:
    """Inspect an explicitly selected file or a file inside the sample directory."""
    if not isinstance(path, str) or not path.strip():
        return result_error("Provide a CSS file path.")
    try:
        target = Path(path).expanduser().resolve(strict=True)
        allowed_sample = False
        if sample_dir is not None:
            root = Path(sample_dir).expanduser().resolve(strict=True)
            allowed_sample = target == root or root in target.parents
        if not selected_file and not allowed_sample:
            return result_error("Select the file explicitly or use a file in the sample directory.")
        if not target.is_file():
            return result_error("The selected path is not a file.")
        if target.suffix.lower() != ".css":
            return result_error("The selected file must have a .css extension.")
        content = target.read_text(encoding="utf-8")
        analysis = analyze_css(content)
        return result_ok(
            {
                "name": target.name,
                "extension": target.suffix,
                "size_bytes": target.stat().st_size,
                "statistics": analysis["summary"],
            }
        )
    except FileNotFoundError:
        return result_error("File not found.")
    except (OSError, UnicodeError, ValueError) as exc:
        return result_error(f"Could not inspect the CSS file: {exc}")
