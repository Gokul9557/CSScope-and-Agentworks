"""Convert structured tool results into concise, task-specific answer views."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class AnswerView:
    title: str
    headline: str
    description: str
    metrics: tuple[tuple[str, str], ...] = ()
    text: str | None = None
    details: tuple[tuple[str, str], ...] = ()


def _format_number(value: int | float) -> str:
    if isinstance(value, int):
        return f"{value:,}"
    return f"{value:,.10g}"


def _format_size(byte_count: int) -> str:
    if byte_count < 1024:
        return f"{byte_count} B"
    if byte_count < 1024**2:
        return f"{byte_count / 1024:.1f} KB"
    return f"{byte_count / 1024**2:.1f} MB"


def build_answer_view(task: str, data: dict[str, Any]) -> AnswerView:
    """Build the user-facing answer for a successful tool result."""
    if task == "Calculate arithmetic":
        value = data["result"]
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise ValueError("Calculator result must be numeric.")
        return AnswerView(
            title="Calculation complete",
            headline=_format_number(value),
            description=f"{data['expression']} = {_format_number(value)}",
        )

    if task in ("Count words", "Count characters"):
        label, key = (
            ("Words", "word_count")
            if task == "Count words"
            else ("Characters", "character_count")
        )
        count = data[key]
        return AnswerView(
            title=f"{label} counted",
            headline=_format_number(count),
            description=f"Your text contains {_format_number(count)} {label.lower()}.",
            metrics=((label, _format_number(count)),),
        )

    if task == "Summarize text":
        return AnswerView(
            title="Text snapshot",
            headline="Summary ready",
            description="A concise view of the text you provided.",
            metrics=(
                ("Words", _format_number(data["word_count"])),
                ("Characters", _format_number(data["character_count"])),
            ),
            text=data["summary"],
        )

    if task == "Inspect sample CSS file":
        stats = data["statistics"]
        return AnswerView(
            title="Stylesheet inspection",
            headline=data["name"],
            description=f"{data['extension'].lstrip('.').upper()} stylesheet · {_format_size(data['size_bytes'])}",
            metrics=tuple(
                (label, _format_number(stats[key]))
                for label, key in (
                    ("Selectors", "selectors"),
                    ("Declarations", "declarations"),
                    ("At-rules", "at_rules"),
                    ("Errors", "errors"),
                )
            ),
            details=tuple(
                (label, _format_number(stats[key]))
                for label, key in (
                    ("Qualified rules", "qualified_rules"),
                    ("Warnings", "warnings"),
                    ("Comments", "comments"),
                    ("Custom properties", "custom_properties"),
                    ("Media queries", "media_queries"),
                    ("Keyframes", "keyframes"),
                )
            ),
        )

    return AnswerView(
        title="Tool result",
        headline="Task complete",
        description="The tool returned a structured result.",
        details=tuple((str(key), str(value)) for key, value in data.items()),
    )
