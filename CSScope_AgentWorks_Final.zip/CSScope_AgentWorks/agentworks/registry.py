"""Descriptions and lookup for callable tools."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable

from .tools import calculator, inspect_css_file, text_utility


@dataclass(frozen=True)
class Tool:
    name: str
    description: str
    function: Callable[..., dict[str, Any]]


class ToolRegistry:
    def __init__(self) -> None:
        self._tools = {
            tool.name: tool
            for tool in (
                Tool("calculator", "Safely calculate basic arithmetic.", calculator),
                Tool(
                    "text",
                    "Count words or characters, or create a short text summary.",
                    text_utility,
                ),
                Tool(
                    "css_inspector",
                    "Inspect an explicitly selected CSS file or sample-directory file.",
                    inspect_css_file,
                ),
            )
        }

    def get(self, name: str) -> Tool | None:
        return self._tools.get(name)

    def describe(self) -> list[dict[str, str]]:
        return [
            {"name": tool.name, "description": tool.description}
            for tool in self._tools.values()
        ]

    def names(self) -> tuple[str, ...]:
        return tuple(self._tools)
