"""Rule-based request router with a sequential execution history."""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from .registry import ToolRegistry
from .tools import result_error


class ToolController:
    """A deterministic router; it does not call or imitate an LLM."""

    def __init__(self, registry: ToolRegistry | None = None) -> None:
        self.registry = registry or ToolRegistry()
        self.history: list[dict[str, Any]] = []

    @staticmethod
    def _route(request: str) -> str | None:
        text = request.lower()
        if any(word in text for word in ("calculate", "calculator", "compute", "what is")):
            return "calculator"
        if any(word in text for word in ("css file", "inspect css", "stylesheet file")):
            return "css_inspector"
        if any(word in text for word in ("word count", "character count", "summarize", "summary", "text")):
            return "text"
        return None

    def run(self, request: str, *, tool_name: str | None = None, **arguments: Any) -> dict[str, Any]:
        if not isinstance(request, str) or not request.strip():
            output = result_error("Enter a request before running a tool.")
            chosen = tool_name or "unresolved"
        else:
            chosen = tool_name or self._route(request)
            if chosen is None:
                output = result_error(
                    "I could not match that request. Try a calculation, text task, or CSS file inspection."
                )
                chosen = "unresolved"
            else:
                tool = self.registry.get(chosen)
                if tool is None:
                    output = result_error(f"Unknown tool: {chosen}.")
                else:
                    try:
                        output = tool.function(**arguments)
                    except TypeError as exc:
                        output = result_error(f"Invalid tool inputs: {exc}")
                    except Exception as exc:
                        output = result_error(f"Tool execution failed: {exc}")
        self.history.append(
            {
                "id": len(self.history) + 1,
                "timestamp": datetime.now(timezone.utc).isoformat(timespec="seconds"),
                "request": request,
                "tool": chosen,
                "result": output,
            }
        )
        return output
