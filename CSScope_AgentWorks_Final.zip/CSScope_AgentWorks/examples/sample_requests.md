# AgentWorks sample requests

Use these requests in the Tool Lab:

- `calculate 18 * (4 + 2)`
- `word count` with any text supplied in the text panel
- `summarize` with a paragraph in the text panel
- `inspect css` with the included `sample_styles.css`

AgentWorks uses a deterministic, rule-based router and works without an API key.
