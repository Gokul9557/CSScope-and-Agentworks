from csscope.parser import analyze_css


def test_ordinary_css_and_selector_lists():
    result = analyze_css(".card, .panel { color: navy; margin: 0; }")
    assert result["summary"]["selectors"] == 2
    assert result["summary"]["qualified_rules"] == 1
    assert result["summary"]["declarations"] == 2
    assert result["declarations"][0]["value"] == "navy"


def test_empty_stylesheet_is_valid():
    result = analyze_css("")
    assert result["summary"]["selectors"] == 0
    assert result["summary"]["errors"] == 0


def test_malformed_declaration_is_reported_as_error():
    result = analyze_css(".x { color red; }")
    assert result["summary"]["errors"] >= 1
    assert result["diagnostics"][0]["severity"] == "error"


def test_comments_are_recognized():
    result = analyze_css("/* top */ .x { /* inside */ color: red; }")
    assert result["summary"]["comments"] == 2


def test_custom_properties_are_extracted():
    result = analyze_css(":root { --brand: teal; color: var(--brand); }")
    assert result["summary"]["custom_properties"] == 1
    assert result["custom_properties"][0]["value"] == "teal"


def test_media_queries_keyframes_and_nested_rules():
    result = analyze_css(
        "@media (min-width: 600px) { .card { color: red; } } "
        "@keyframes fade { from { opacity: 0; } to { opacity: 1; } }"
    )
    assert result["summary"]["at_rules"] == 2
    assert result["summary"]["media_queries"] == 1
    assert result["summary"]["keyframes"] == 1
    assert result["summary"]["qualified_rules"] == 3
    assert result["selectors"][0]["at_rule_context"] == ["@media (min-width: 600px)"]


def test_duplicate_properties_are_warnings_not_errors():
    result = analyze_css(".x { color: red; color: blue; }")
    assert result["summary"]["warnings"] == 1
    assert result["summary"]["errors"] == 0
