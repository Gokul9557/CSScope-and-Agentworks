from agentworks.presentation import build_answer_view


def test_calculation_answer_is_displayed_as_a_readable_equation():
    view = build_answer_view(
        "Calculate arithmetic", {"expression": "18 * (4 + 2)", "result": 108}
    )
    assert view.headline == "108"
    assert view.description == "18 * (4 + 2) = 108"


def test_text_answers_use_task_specific_count_and_summary():
    word_view = build_answer_view("Count words", {"word_count": 1250})
    summary_view = build_answer_view(
        "Summarize text",
        {"word_count": 12, "character_count": 68, "summary": "A short example."},
    )
    assert word_view.headline == "1,250"
    assert word_view.metrics == (("Words", "1,250"),)
    assert summary_view.text == "A short example."
    assert summary_view.metrics == (("Words", "12"), ("Characters", "68"))


def test_css_inspection_answer_highlights_key_statistics_and_details():
    statistics = {
        "selectors": 7,
        "qualified_rules": 5,
        "declarations": 10,
        "at_rules": 2,
        "errors": 0,
        "warnings": 1,
        "comments": 2,
        "custom_properties": 3,
        "media_queries": 1,
        "keyframes": 1,
    }
    view = build_answer_view(
        "Inspect sample CSS file",
        {
            "name": "sample.css",
            "extension": ".css",
            "size_bytes": 1536,
            "statistics": statistics,
        },
    )
    assert view.headline == "sample.css"
    assert view.description == "CSS stylesheet · 1.5 KB"
    assert ("Selectors", "7") in view.metrics
    assert ("Keyframes", "1") in view.details


def test_calculation_answer_rejects_non_numeric_results():
    try:
        build_answer_view("Calculate arithmetic", {"expression": "x", "result": True})
    except ValueError as error:
        assert "numeric" in str(error)
    else:
        raise AssertionError("Expected boolean result validation to fail.")
