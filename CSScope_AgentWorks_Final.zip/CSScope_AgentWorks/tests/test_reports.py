import json

from csscope.parser import analyze_css
from csscope.reports import format_report, to_json_report


def test_json_report_round_trips_analysis():
    analysis = analyze_css(".x { color: red; }")
    assert json.loads(to_json_report(analysis)) == analysis


def test_readable_report_contains_summary_and_selector():
    report = format_report(analyze_css(".x { color: red; }"))
    assert "CSScope Analysis" in report
    assert "Selectors: 1" in report
    assert "- .x" in report
