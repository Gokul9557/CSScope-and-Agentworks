from agentworks.controller import ToolController


def test_controller_routes_calculator_and_text():
    controller = ToolController()
    calculated = controller.run("calculate 2 + 3", expression="2 + 3")
    words = controller.run(
        "word count", tool_name="text", text="one two", operation="word_count"
    )
    assert calculated["data"]["result"] == 5
    assert words["data"]["word_count"] == 2


def test_controller_handles_unknown_requests_tools_and_bad_inputs():
    controller = ToolController()
    assert controller.run("do something mysterious")["ok"] is False
    assert controller.run("anything", tool_name="missing")["error"] == "Unknown tool: missing."
    assert controller.run("calculate", tool_name="calculator")["ok"] is False


def test_controller_records_sequential_timestamped_history():
    controller = ToolController()
    controller.run("calculate", tool_name="calculator", expression="3 * 3")
    controller.run("summarize", tool_name="text", text="hello world", operation="summary")
    assert [item["id"] for item in controller.history] == [1, 2]
    assert all(item["timestamp"].endswith("+00:00") for item in controller.history)
