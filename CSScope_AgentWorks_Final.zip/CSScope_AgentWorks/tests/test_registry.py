from pathlib import Path

from agentworks.registry import ToolRegistry
from agentworks.tools import calculator, inspect_css_file, text_utility


def test_registry_exposes_described_tools():
    registry = ToolRegistry()
    assert set(registry.names()) == {"calculator", "text", "css_inspector"}
    assert all(item["description"] for item in registry.describe())
    assert registry.get("not_a_tool") is None


def test_calculator_safe_arithmetic_and_invalid_expression():
    assert calculator("2 * (3 + 4)")["data"]["result"] == 14
    assert calculator("__import__('os')")["ok"] is False
    assert calculator("1 / 0")["ok"] is False


def test_text_utility_operations_and_validation():
    assert text_utility("one two", "word_count")["data"]["word_count"] == 2
    assert text_utility("abc", "character_count")["data"]["character_count"] == 3
    assert text_utility("one two", "summary")["data"]["summary"] == "one two"
    assert text_utility("x", "other")["ok"] is False


def test_css_inspector_file_scope_and_missing_file(tmp_path: Path):
    sample_dir = tmp_path / "samples"
    sample_dir.mkdir()
    css_file = sample_dir / "sample.css"
    css_file.write_text(".x { color: red; }", encoding="utf-8")
    inspected = inspect_css_file(str(css_file), sample_dir=sample_dir)
    assert inspected["ok"] is True
    assert inspected["data"]["extension"] == ".css"
    assert inspected["data"]["statistics"]["declarations"] == 1
    assert inspect_css_file(str(css_file))["ok"] is False
    assert inspect_css_file(str(sample_dir / "missing.css"), sample_dir=sample_dir)["ok"] is False
    txt_file = sample_dir / "readme.txt"
    txt_file.write_text("hello", encoding="utf-8")
    assert inspect_css_file(str(txt_file), sample_dir=sample_dir)["ok"] is False
