"""CSS analysis and reporting package."""

from .parser import analyze_css

__all__ = ["analyze_css"]
