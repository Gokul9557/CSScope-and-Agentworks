"""Export and format CSScope analysis results."""

from __future__ import annotations

import json
from typing import Any


def to_json_report(analysis: dict[str, Any], *, indent: int = 2) -> str:
    """Serialize an analysis document as UTF-8-friendly JSON."""
    return json.dumps(analysis, indent=indent, ensure_ascii=False)


def format_report(analysis: dict[str, Any]) -> str:
    """Create a concise, readable text report."""
    summary = analysis["summary"]
    lines = [
        "CSScope Analysis",
        "================",
        f"Selectors: {summary['selectors']}",
        f"Declarations: {summary['declarations']}",
        f"At-rules: {summary['at_rules']}",
        f"Errors: {summary['errors']}",
        f"Warnings: {summary['warnings']}",
        f"Comments: {summary['comments']}",
        f"Custom properties: {summary['custom_properties']}",
    ]
    if analysis["selectors"]:
        lines.extend(["", "Selectors"])
        lines.extend(f"- {item['selector']}" for item in analysis["selectors"])
    if analysis["diagnostics"]:
        lines.extend(["", "Diagnostics"])
        lines.extend(
            f"- {item['severity'].title()} (line {item['line']}): {item['message']}"
            for item in analysis["diagnostics"]
        )
    return "\n".join(lines)
