"""Parse CSS into a JSON-friendly analysis document."""

from __future__ import annotations

from typing import Any

import tinycss2
from tinycss2.ast import AtRule, Comment, Declaration, ParseError, QualifiedRule


DECLARATION_AT_RULES = {"font-face", "page", "counter-style", "property"}


def _serialize(tokens: list[Any]) -> str:
    return tinycss2.serialize(tokens).strip()


def _selector_count(prelude: list[Any]) -> int:
    """Count selector-list members without splitting commas inside functions."""
    count = 1
    depth = 0
    for token in prelude:
        if token.type == "literal":
            if token.value in ("(", "["):
                depth += 1
            elif token.value in (")", "]"):
                depth = max(0, depth - 1)
            elif token.value == "," and depth == 0:
                count += 1
    return count


def analyze_css(source: str) -> dict[str, Any]:
    """Analyze CSS source, preserving recoverable parse errors as diagnostics."""
    if not isinstance(source, str):
        raise TypeError("CSS source must be text.")

    document: dict[str, Any] = {
        "selectors": [],
        "declarations": [],
        "at_rules": [],
        "diagnostics": [],
        "comments": 0,
        "custom_properties": [],
    }

    def add_parse_error(error: ParseError, context: str) -> None:
        document["diagnostics"].append(
            {
                "severity": "error",
                "message": error.message,
                "line": error.source_line,
                "column": error.source_column,
                "context": context,
            }
        )

    def process_declarations(tokens: list[Any], context: str) -> None:
        declarations = tinycss2.parse_declaration_list(
            tokens, skip_comments=False, skip_whitespace=True
        )
        seen_properties: set[str] = set()
        for item in declarations:
            if isinstance(item, Comment):
                document["comments"] += 1
            elif isinstance(item, ParseError):
                add_parse_error(item, context)
            elif isinstance(item, Declaration):
                value = _serialize(item.value)
                entry = {
                    "context": context,
                    "property": item.name,
                    "value": value,
                    "important": item.important,
                    "line": item.source_line,
                    "column": item.source_column,
                }
                document["declarations"].append(entry)
                if item.name in seen_properties:
                    document["diagnostics"].append(
                        {
                            "severity": "warning",
                            "message": f"Duplicate declaration for '{item.name}'.",
                            "line": item.source_line,
                            "column": item.source_column,
                            "context": context,
                        }
                    )
                seen_properties.add(item.name)
                if item.name.startswith("--"):
                    document["custom_properties"].append(entry.copy())

    def process_rules(rules: list[Any], parents: tuple[str, ...] = ()) -> None:
        for rule in rules:
            if isinstance(rule, Comment):
                document["comments"] += 1
            elif isinstance(rule, ParseError):
                add_parse_error(rule, "stylesheet")
            elif isinstance(rule, QualifiedRule):
                selector = _serialize(rule.prelude)
                document["selectors"].append(
                    {
                        "selector": selector,
                        "selector_count": _selector_count(rule.prelude),
                        "at_rule_context": list(parents),
                        "line": rule.source_line,
                        "column": rule.source_column,
                    }
                )
                process_declarations(rule.content, selector)
            elif isinstance(rule, AtRule):
                name = rule.lower_at_keyword
                prelude = _serialize(rule.prelude)
                label = f"@{name}" + (f" {prelude}" if prelude else "")
                document["at_rules"].append(
                    {
                        "name": name,
                        "prelude": prelude,
                        "context": list(parents),
                        "line": rule.source_line,
                        "column": rule.source_column,
                    }
                )
                if rule.content is None:
                    continue
                if name in DECLARATION_AT_RULES:
                    process_declarations(rule.content, label)
                    continue
                nested = tinycss2.parse_rule_list(
                    rule.content, skip_comments=False, skip_whitespace=True
                )
                process_rules(nested, parents + (label,))

    rules = tinycss2.parse_stylesheet(
        source, skip_comments=False, skip_whitespace=True
    )
    process_rules(rules)

    document["summary"] = {
        "selectors": sum(item["selector_count"] for item in document["selectors"]),
        "qualified_rules": len(document["selectors"]),
        "declarations": len(document["declarations"]),
        "at_rules": len(document["at_rules"]),
        "errors": sum(
            item["severity"] == "error" for item in document["diagnostics"]
        ),
        "warnings": sum(
            item["severity"] == "warning" for item in document["diagnostics"]
        ),
        "comments": document["comments"],
        "custom_properties": len(document["custom_properties"]),
        "media_queries": sum(item["name"] == "media" for item in document["at_rules"]),
        "keyframes": sum(
            item["name"] in ("keyframes", "-webkit-keyframes")
            for item in document["at_rules"]
        ),
    }
    return document
